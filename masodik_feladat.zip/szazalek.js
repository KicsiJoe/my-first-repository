
export const szazalekSzamitas = (osszDb, kitoltDb) => {

    return Math.round(kitoltDb/osszDb * 100)
}