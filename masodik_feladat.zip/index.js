import { szamolasok } from "./szamolas.js";

document.addEventListener("DOMContentLoaded", () => szamolasok());

